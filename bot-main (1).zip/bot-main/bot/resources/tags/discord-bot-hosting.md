---
embed:
    title: Discord Bot Hosting
---

Using free hosting options like repl.it or Heroku for continuous 24/7 bot hosting is strongly discouraged.
Instead, opt for a virtual private server (VPS) or use your own spare hardware if you'd rather not pay for hosting.

See our [Discord Bot Hosting Guide](https://www.pythondiscord.com/pages/guides/python-guides/vps-services/) on our website that compares many hosting providers, both free and paid.

You may also use <#965291480992321536> to discuss different discord bot hosting options.
