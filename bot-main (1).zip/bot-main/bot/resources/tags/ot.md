---
embed:
    title: "Off-topic channel"
---
<#463035268514185226>

Please read our [off-topic etiquette](https://pythondiscord.com/pages/resources/guides/off-topic-etiquette/) before participating in conversations.
